<?php
/**
 * DigiNova Plus functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package DigiNova_Plus
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define theme constants.
define( 'DIGINOVAPLUS_VERSION', '1.0.0' );
define( 'DIGINOVAPLUS_DIR', trailingslashit( get_template_directory() ) );
define( 'DIGINOVAPLUS_URI', trailingslashit( get_template_directory_uri() ) );

/**
 * Require core theme classes.
 */
require_once DIGINOVAPLUS_DIR . 'inc/class-theme-setup.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-assets.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-ajax-handler.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-customizer.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-demo-import.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-woocommerce.php';
require_once DIGINOVAPLUS_DIR . 'inc/class-plugins-loader.php';

// Initialize core classes.
DigiNova_Plus_Theme_Setup::get_instance();
DigiNova_Plus_Assets::get_instance();

/**
 * Include TGMPA Plugin Activation.
 * Assuming TGM-Plugin-Activation library is included or will be added.
 */
// require_once DIGINOVAPLUS_DIR . 'inc/tgmpa/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'diginovaplus_register_required_plugins' );
function diginovaplus_register_required_plugins() {
	$plugins = array(
		array(
			'name'     => 'Elementor',
			'slug'     => 'elementor',
			'required' => true,
		),
		array(
			'name'     => 'WooCommerce',
			'slug'     => 'woocommerce',
			'required' => true,
		),
		array(
			'name'     => 'One Click Demo Import',
			'slug'     => 'one-click-demo-import',
			'required' => true,
		),
		array(
			'name'               => 'DigiNova Plus Core',
			'slug'               => 'diginovaplus-core',
			'source'             => get_template_directory() . '/plugins/diginovaplus-core.zip', // Will bundle this later or host on GitHub
			'required'           => true,
			'version'            => '1.0.0',
			'force_activation'   => false,
			'force_deactivation' => false,
		),
	);

	$config = array(
		'id'           => 'diginovaplus',
		'default_path' => '',
		'menu'         => 'tgmpa-install-plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'dismiss_msg'  => '',
		'is_automatic' => false,
		'message'      => '',
	);

	if ( function_exists( 'tgmpa' ) ) {
		tgmpa( $plugins, $config );
	}
}

// Ensure theme support for Title Tag
add_theme_support( 'title-tag' );
